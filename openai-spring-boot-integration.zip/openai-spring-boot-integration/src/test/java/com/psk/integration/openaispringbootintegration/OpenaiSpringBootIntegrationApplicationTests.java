package com.psk.integration.openaispringbootintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenaiSpringBootIntegrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
