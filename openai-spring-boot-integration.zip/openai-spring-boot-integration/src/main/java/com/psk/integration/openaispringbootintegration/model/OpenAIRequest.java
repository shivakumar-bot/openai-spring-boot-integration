package com.psk.integration.openaispringbootintegration.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class OpenAIRequest {

  private String model;
  private List<MessageInput> messageInputs;
  private int n;
  private double temperature;
  private int max_tokens;
}
