package com.psk.integration.openaispringbootintegration.controller;


import com.psk.integration.openaispringbootintegration.model.OpenAIRequest;
import com.psk.integration.openaispringbootintegration.model.OpenAIResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import com.psk.integration.openaispringbootintegration.model.MessageInput;

import java.util.List;

@RestController
public class OpenAIController {

  @Autowired
  private RestTemplate restTemplate;

  @Value("${openai.model}")
  private String model;

  @Value("${openai.max-completions}")
  private int maxCompletions;

  @Value("${openai.temperature}")
  private double temperature;

  @Value("${openai.max_tokens}")
  private int maxTokens;

  @Value("${openai.api.url}")
  private String apiUrl;

  @PostMapping("/chat")
  public OpenAIResponse chat(@RequestParam("prompt") String prompt) {

    OpenAIRequest request = new OpenAIRequest(model,
        List.of(new MessageInput("user", prompt)),
        maxCompletions,
        temperature,
        maxTokens);

    OpenAIResponse response = restTemplate.postForObject(apiUrl, request, OpenAIResponse.class);
    return response;
  }
}
